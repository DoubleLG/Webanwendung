package de.hs_lu.beans;

import de.hs_lu.database.MySQL;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

/**
 * Created by Shadow on 03.10.2016.
 */
public class DishBean {
    Vector<DishStats> auswertung;


    public DishBean() throws SQLException, ClassNotFoundException {
        super();
        auswertung = new Vector<DishStats>();
        this.getStats();
    }

    public void saveDish(String[] foods, String[] amounts, int userId, Date dishTimestamp) throws SQLException, ClassNotFoundException {

        java.sql.Date sqlDate = new java.sql.Date(dishTimestamp.getTime());

        for (int i = 0; i < foods.length; i++) {

            String sql = "INSERT INTO dishes (NUTRITION_ID, USER_ID, AMOUNT, TIMESTAMP) VALUES (?,?,?,?)";

            Connection dbConn = new MySQL().getConnection();

            PreparedStatement prep = dbConn.prepareStatement(sql);

            prep.setInt(1, Integer.parseInt(foods[i]));
            prep.setInt(2, userId);
            prep.setInt(3, Integer.parseInt(amounts[i]));
            prep.setDate(4, sqlDate);

            prep.executeUpdate();
        }
    }

    public void getStats() throws SQLException, ClassNotFoundException {
        String sql = "SELECT timestamp as stat_day, Sum(n.Eiweiß*d.amount) as Eiweiß, Sum(n.Fett*d.amount)as Fett, Sum(n.Kcal*d.amount) as Kalorien, Sum(n.Kjoule*d.amount) as Kjoule, Sum(n.Kohlehydrate*d.amount) as Kohlehydrate from dishes as d,nutrition as n, users as u Where d.nutrition_ID = n.ID AND d.user_id = 30 group by timestamp order by stat_day";

        Connection dbConn = new MySQL().getConnection();

        // Prepared Statement, welches auf die UserId zugreift wurde nicht implementiert.
        PreparedStatement prep = dbConn.prepareStatement(sql);

        ResultSet rs = prep.executeQuery();

        while (rs.next()) {
            DishStats auswertungsEintrag = new DishStats(rs.getDate("stat_day"),
                    rs.getDouble("eiweiß"),
                    rs.getDouble("fett"),
                    rs.getDouble("kalorien"),
                    rs.getDouble("kjoule"),
                    rs.getDouble("kohlehydrate")

            );
            auswertung.add(auswertungsEintrag);
        }
    }

    public String getHTMLFromDishTable() {
        String html = "";

        for(DishStats data : auswertung) {
            html += "<tr>" + data.toTableRow() + "</tr>";
        }

        return html;
    }

}
